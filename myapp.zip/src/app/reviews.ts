export default [{
  "id": "XyDhV_bmH8cKWN9-7ow9nQ",
  "url": "https://www.yelp.com/biz/the-little-snail-restaurant-pyrmont?hrid=XyDhV_bmH8cKWN9-7ow9nQ&adjust_creative=j8NgHYhqe0GlJfIvqvKnKA&utm_campaign=yelp_api_v3&utm_medium=api_v3_business_reviews&utm_source=j8NgHYhqe0GlJfIvqvKnKA",
  "text": "What a hidden gem! This cute restaurant is located right next to Darling Harbour but away from all the tourist traps. We find a voucher on Groupon and...",
  "rating": 5,
  "time_created": "2018-02-23 22:47:29",
  "user": {"image_url": "https://s3-media1.fl.yelpcdn.com/photo/8ndgqGOviAWldA2Mlu9eOg/o.jpg", "name": "Danielle K."}
}, {
  "id": "6wM-obHImhyEqPwucjKV_g",
  "url": "https://www.yelp.com/biz/the-little-snail-restaurant-pyrmont?hrid=6wM-obHImhyEqPwucjKV_g&adjust_creative=j8NgHYhqe0GlJfIvqvKnKA&utm_campaign=yelp_api_v3&utm_medium=api_v3_business_reviews&utm_source=j8NgHYhqe0GlJfIvqvKnKA",
  "text": "Exceptional little restaurant in a convenient location. \n\nA short walk away from the Convention light rail station and The Harbourside mall, the Little...",
  "rating": 5,
  "time_created": "2017-07-18 04:20:40",
  "user": {"image_url": "https://s3-media3.fl.yelpcdn.com/photo/nDVWO6Cn39-uU17BKB96KQ/o.jpg", "name": "Rich H."}
}, {
  "id": "nKYwqlBjdrNgtCBb37LDOA",
  "url": "https://www.yelp.com/biz/the-little-snail-restaurant-pyrmont?hrid=nKYwqlBjdrNgtCBb37LDOA&adjust_creative=j8NgHYhqe0GlJfIvqvKnKA&utm_campaign=yelp_api_v3&utm_medium=api_v3_business_reviews&utm_source=j8NgHYhqe0GlJfIvqvKnKA",
  "text": "The two of us were on a voucher which saves about 50%. The menu choice is the $60pp. We had three courses. The snails were good although I was missing two...",
  "rating": 4,
  "time_created": "2016-10-24 20:30:51",
  "user": {"image_url": "https://s3-media4.fl.yelpcdn.com/photo/bpj4uVg5n5JL9GuMal1EwQ/o.jpg", "name": "Sue L."}
}]
